
#_____________________________________________________________________________
#_____________________________________________________________________________

# INSTALLED FOLLOWING SOFTWARES
	vim
	Google Chrome

# INSTALLING SUBLIME TEXT
sudo snap install sublime-text --classic

# INSTALLING BUILD ESSENTIALS

sudo apt update
sudo apt install build-essential
sudo apt install cmake

# INSTALLING SSH

sudo apt install ssh
sudo systemctl enable ssh
sudo systemctl start ssh

# INSTALLING NET TOOLS

e.g. For ifconfig Command
sudo apt install net-tools


33  cd Downloads/
34  ls
35  sudo apt install ./google-chrome-stable_current_amd64.deb 
36  sudo apt install vim
37  vim
38  sudo apt installl vim
39  sudo apt install vim
40  sudo apt update
41  sudo apt install build-essential
43  sudo apt update
44  sudo apt install vim
45  vim
46  sudo apt install cmake
47  cmake
48  make
50  java
51  javac
52  sudo apt install default-jdk
53  java -version
54  javac -version
55  sudo snap install sublime-text --classic
56  sudo apt install net-tools
57  sudo apt install ssh
58  sudo apt install enable ssh
59  sudo systemctl enable ssh
60  sudo systemctl start ssh
61  sudo snap install code --classic

#_____________________________________________________________________________
#_____________________________________________________________________________


1. Install Ananconda
	
	~/Documents/Repository

	./Anaconda3-2021.11-Linux-x86_64.sh

2. Update Conda
	conda update -n base -c defaults conda

3. Create Conda Environment Named Quantum
	conda create -n Quantum python=3

4.1 Installing Qiskit
	Reference Link : https://qiskit.org/documentation/getting_started.html

	pip install qiskit
	pip install qiskit[visualization]

4.2 Configuring Qiskit
	(Quantum) khoj@ubuntu2204:~/.qiskit$ cat settings.conf 
	[default]
	circuit_drawer = mpl

4.3	Testing Qiskit Code: RandomBit.py

	## Programming Quantum Computers
	##   by Eric Johnston, Nic Harrigan and Mercedes Gimeno-Segovia
	##   O'Reilly Media
	##
	## More samples like this can be found at http://oreilly-qc.github.io

	## This sample generates a single random bit.

	from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, execute, Aer, IBMQ, BasicAer
	import math
	## Uncomment the next line to see diagrams when running in a notebook
	#%matplotlib inline

	## Example 2-1: Random bit
	# Set up the program
	reg = QuantumRegister(1, name='reg')
	reg_c = ClassicalRegister(1, name='regc')
	qc = QuantumCircuit(reg, reg_c)

	qc.reset(reg)          # write the value 0
	qc.h(reg)              # put it into a superposition of 0 and 1
	qc.measure(reg, reg_c) # read the result as a digital bit

	backend = BasicAer.get_backend('statevector_simulator')
	job = execute(qc, backend)
	result = job.result()

	counts = result.get_counts(qc)
	print('counts:',counts)

	outputstate = result.get_statevector(qc, decimals=3)
	print(outputstate)
	qc.draw()        # draw the circuit

4.4	Testing Qiskit Code
	
	qc.draw(output='mpl', style={'backgroundcolor': '#EEEEEE'}, filename="./circuitImage")


5. Installing Qiskit Textbook [ In Conda Quantum Environment ]
	Reference Link : https://learn.qiskit.org/course/ch-prerequisites/environment-setup-guide-to-work-with-qiskit-textbook

	The Qiskit Textbook provides some tools and widgets specific to the Textbook. This is not part of Qiskit and is available through the qiskit_textbook package. The quickest way to install this with Pip and Git is through the command:

		pip install git+https://github.com/qiskit-community/qiskit-textbook.git#subdirectory=qiskit-textbook-src
	Alternatively, you can download the folder qiskit-textbook-src from the Github and run:
		https://github.com/qiskit-community/qiskit-textbook

		pip install ./qiskit-textbook-src

		from the directory that contains this folder.

	Installing the LaTeX parser
		
		To get a rendering similar to the Qiskit Textbook, optionally install the pylatexenc library. You can do this with Pip and Git through the command :

		pip install pylatexenc

6. Installing cirq [ In Conda Quantum Environment ]

	Reference Link: https://quantumai.google/cirq/install

	Use pip to install cirq:

		python -m pip install --upgrade pip
		python -m pip install cirq

	(Optional) install other dependencies.
		Install dependencies of features in cirq.contrib.

			python -m pip install cirq-core[contrib]

		Install system dependencies that pip can't handle.

			sudo apt-get install texlive-latex-base latexmk
			
			Without texlive-latex-base and latexmk, pdf writing functionality will not work

	Check that it works!

		python -c 'import cirq_google; print(cirq_google.Sycamore)'


	Create HelloCriq.py And Run!

		import cirq
		# Pick a qubit.
		qubit = cirq.GridQubit(0, 0)

		# Create a circuit
		circuit = cirq.Circuit(
		    cirq.X(qubit)**0.5,  # Square root of NOT.
		    cirq.measure(qubit, key='m')  # Measurement.
		)
		print("Circuit:")
		print(circuit)

		# Simulate the circuit several times.
		simulator = cirq.Simulator()
		result = simulator.run(circuit, repetitions=20)
		print("Results:")
		print(result)

7. Installing Q#, QDK [ In Conda Qsharp Environment ]

	Create Conda Environment Named Qsharp

		conda create -n Qsharp -c microsoft qsharp notebook
		conda activate Qsharp

	Installing Visual Studio Code

		sudo snap install code --classic

		Install Microsoft Quantum Development Kit
			Microsoft QDK

		Install Microsoft .NET Extensions
			.NET Core Tools
			.NET Extensions Pack
			.NET Interactive Notebooks

	Installing .NET SDK
	
		Using Snap Package
		Reference Link : https://docs.microsoft.com/en-us/dotnet/core/install/linux-snap

			sudo snap install dotnet-sdk --classic

			Use the snap install command to install a .NET SDK snap package. Use the --channel parameter to indicate which version to install. If this parameter is omitted, latest/stable is used. In this example, 6.0 is specified:

				sudo snap install dotnet-sdk --classic --channel=6.0

					khoj@ubuntu2204:/media/WorkArea/Environment/QuantumComputingEnvironment$ sudo snap install dotnet-sdk --classic
					[sudo] password for khoj: 
					dotnet-sdk 6.0.300 from Microsoft .NET Core (dotnetcore*) installed

			Next, register the dotnet command for the system with the snap alias command:

				sudo snap alias dotnet-sdk.dotnet dotnet


		Using .deb Package
		Reference Link : https://docs.microsoft.com/en-gb/dotnet/core/install/linux-ubuntu

			Download .NET SDK
			
				wget https://packages.microsoft.com/config/ubuntu/22.04/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
				sudo dpkg -i packages-microsoft-prod.deb
				rm packages-microsoft-prod.deb

			Install .NET SDK

				sudo apt-get update; \
				  sudo apt-get install -y apt-transport-https && \
				  sudo apt-get update && \
				  sudo apt-get install -y dotnet-sdk-6.0


	Create C# HelloWorld Project
		Reference Link :

		Create HelloWorld

			dotnet new console -o HelloWorld

		Run HelloWorld

			cd HelloWorld/
			dotnet run

	Set up a Q# standalone environment

		Install .NET Core In System Path

			wget https://packages.microsoft.com/config/ubuntu/20.04/packages-microsoft-prod.deb -O packages-microsoft-prod.deb
			sudo dpkg -i packages-microsoft-prod.deb


		Install .NET SDK 

			sudo apt-get update; \
			  sudo apt-get install -y apt-transport-https && \
			  sudo apt-get update && \
			  sudo apt-get install -y dotnet-sdk-6.0


		Installed .NET SDK Have Few Things Missing
		:::ISSUE:::

				/Documents/Repository/TestEnvironment$ dotnet iqsharp install --user
				Process terminated. Couldn't find a valid ICU package installed on the system. Please install libicu using your package manager and try again. Alternatively you can set the configuration flag System.Globalization.Invariant to true if you want to run with no globalization support. Please see https://aka.ms/dotnet-missing-libicu for more information.


				sudo dpkg --purge packages-microsoft-prod && sudo dpkg -i packages-microsoft-prod.deb
				sudo apt-get update


				sudo apt-get install -y gpg
				wget -O - https://packages.microsoft.com/keys/microsoft.asc | gpg --dearmor -o microsoft.asc.gpg
				sudo mv microsoft.asc.gpg /etc/apt/trusted.gpg.d/
				wget https://packages.microsoft.com/config/ubuntu/{os-version}/prod.list
				sudo mv prod.list /etc/apt/sources.list.d/microsoft-prod.list
				sudo chown root:root /etc/apt/trusted.gpg.d/microsoft.asc.gpg
				sudo chown root:root /etc/apt/sources.list.d/microsoft-prod.list
				sudo apt-get update; \
				  sudo apt-get install -y apt-transport-https && \
				  sudo apt-get update && \
				  sudo apt-get install -y {dotnet-package}


		Install IQ# via the .NET Microsoft.Quantum.IQSharp package.
			Reference Link : 

			dotnet tool install -g Microsoft.Quantum.IQSharp
			dotnet iqsharp install

			dotnet iqsharp install --user

			dotnet new -i Microsoft.Quantum.ProjectTemplates


	Create Q# HelloWorldQ Project
		Reference Link : https://docs.microsoft.com/en-us/azure/quantum/how-to-command-line-local?tabs=tabid-vscode

		Create HelloWorld

			dotnet new console -lang Q# -o HelloWorldQ

		Run HelloWorld

			cd HelloWorldQ/
			dotnet run


