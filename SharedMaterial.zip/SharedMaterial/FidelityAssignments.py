
Reading And Exploration Assignments
_________________________________________________________________________

[ MUST HAVE ]

	A1. Programming Quantum Computer, Orielly  Publication [ MUST HAVE ]
			First 05 Chapters
			Read It Again and Again
	
	A2. Quantum Computing For Everyone [ MUST HAVE ]
			All Chapters			

	2. Complex Numbers and Algebra  [ MUST HAVE ]
	3. Vectors and Vector Algebra   [ MUST HAVE ]
	4. Matrices and Matrix Algebra  [ MUST HAVE ]
_________________________________________________________________________

[ GOOD TO HAVE ]

	5. Linear Algebra [ GOOD TO HAVE ]
			Linear Algebra Step By Step By Kuldeep Singh, Oxford University Press

	6. Probability    [ GOOD TO HAVE ]

_________________________________________________________________________

LinkedIn : www.linkedin.com/in/amarjitlife
Email ID : amarjitlife@gmail.com
Phone    : +91 9980 777 145

_________________________________________________________________________


